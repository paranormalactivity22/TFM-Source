class Langues:
	@staticmethod
	def getLangues():
		return [
			"EN", 
			"FR", 
			"RU", 
			"BR", 
			"ES", 
			"CN", 
			"TR", 
			"VK", 
			"PL", 
			"HU", 
			"NL", 
			"RO", 
			"ID", 
			"DE", 
			"E2", 
			"AR", 
			"PH", 
			"LT", 
			"JP", 
			"CH", 
			"FI", 
			"CZ", 
			"SK", 
			"HR", 
			"BG", 
			"LV", 
			"HE", 
			"IT", 
			"ET", 
			"AZ", 
			"PT"
		]


